package start;

import manager.Manager;

public class Start
{
	public static void main(String[] args)
	{
		new Manager();
	}
}
